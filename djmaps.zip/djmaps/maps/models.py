from django.db import models

# Create your models here.
from django.db import models
from mapbox_location_field.models import LocationField

class SomeLocationModel(models.Model):
    location = LocationField(map_attrs={"center": [0,0], "marker_color": "blue"})
